
export const environment = {
  production: false,
  baseUrl: 'https://behtarzindagi.in/',  
  baseApiUrl: 'https://behtarzindagi.in/BZFarmerApp_Test/', //test server
  //baseApiUrl: 'https://behtarzindagi.in/BZFarmerApp_Live/', // live server 
  loginUrl: 'https://app.astrolive.online/bz/',
};


