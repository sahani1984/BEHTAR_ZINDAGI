import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { MaterialModule } from './views/material.module';
import {ToastrModule} from 'ngx-toastr';
// Component
import { AppComponent } from './app.component';
import { LayoutComponent } from './views/layout/layout.component';
import { HeaderComponent  } from './views/common/header/header.component';
import { FooterComponent } from './views/common/footer/footer.component';
// Modules component
import { SharedModule } from './views/shared/shared.module';
import { CategoryModule } from './views/category/category.module';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { LoaderComponent } from './views/common/loader/loader.component';
import { AgmCoreModule } from '@agm/core';
import { AboutComponent } from './views/about/about.component';
import { RouterModule } from '@angular/router';
import { LoginComponent } from '../app/views/login/login.component';
import { ProfileComponent } from '../app/views/profile/profile.component';
import { OrderHistoryComponent } from '../app/views/order-history/order-history.component';
import { NotificationsComponent } from '../app/views/notifications/notifications.component';
@NgModule({
  declarations: [
    AppComponent,
    LayoutComponent,
    HeaderComponent,
    FooterComponent,
    LoaderComponent,
    AboutComponent,
    LoginComponent,
    ProfileComponent,
    OrderHistoryComponent,
    NotificationsComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,
    MaterialModule,
    SharedModule,
    CategoryModule,
    SlickCarouselModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyAgGdczxA0wa7WGNd1pjJ28Lw01a9aqNfY',
      libraries: ['places']
    }),
    ToastrModule.forRoot({
      timeOut:5000,
        progressBar:true,
        progressAnimation:"increasing"        
      }),
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
