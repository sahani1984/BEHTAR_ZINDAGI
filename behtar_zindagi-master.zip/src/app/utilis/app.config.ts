
import { environment } from "./../../environments/environment";
export const API_PATH = {
    statesList: environment.baseUrl + 'bz_FarmerApp/ProductDetail.svc/api/GetAllStateDistrictBlockVilage?apiKey=123&Id=0&Type=S',
    districtList: environment.baseUrl + 'bz_FarmerApp/ProductDetail.svc/api/GetAllStateDistrictBlockVilage?apiKey=123',
    bannersList: environment.baseApiUrl + 'api/Home/GetBZProductBanner?Version=1',
    farmerCategory: environment.baseApiUrl + 'api/Category/Get_MainCategory',
    topSellingProducts: environment.baseApiUrl + 'api/LiveStock/GetTrendsProducts?Version=1&ProdCount=',
    behtarBachatProducts: environment.baseApiUrl + 'api/LiveStock/GetTodayOfferProduct?Version=1&CategoryId=&ProdCount=',
    topBrands: environment.baseApiUrl + 'api/home/getbzappactivebrands?version=1&ProdCount=0',
    subCategories: environment.baseApiUrl + 'api/Category/Get_BZFarmerAppCatagory_New?version=1&KGP=1&Categoryid=',
    haryanaCategoryProduct: environment.baseApiUrl + 'api/LiveStock/GetCategoryWiseProducts?',
    getSubCategoriesProductsByCategoryId: environment.baseApiUrl + 'api/KitchenGarden/GetKGPCategorySubCategoryWiseDataV2',
    getSubCategoryFilter: environment.baseApiUrl + 'api/KitchenGarden/GetKGPCategoryFilters?Version=1&lang=E&KGP_CategoryId=',
    getProductDetails: environment.baseApiUrl + 'api/Home/v1/GetBzAppProductDetailsNew',
    getProductDetailsWithFarmerId: environment.baseApiUrl + 'api/Home/v1/GetBzAppProductDetailsByFarmerID',
    getOTP: environment.loginUrl + 'sendOTPToMobile',
    verifyOTP: environment.loginUrl + 'validateOTP',
    farmerAppLogin: environment.baseUrl + 'bz_FarmerApp/ProductDetail.svc/api/BZFarmerAPPLogin',
    getBestDeal: environment.baseApiUrl + 'api/Home/Insert_BuyerBestDealNotification',
    farmerAppServices: environment.baseApiUrl + 'api/LiveStock/BZFarmerAppServices?Version=1',
    orderCreate: environment.baseApiUrl + 'api/LiveStock/V1/OrderCreate',
    GetBrandWiseProduct: environment.baseApiUrl + 'api/LiveStock/GetBrandWiseProduct',
    GetTodayOfferProduct: environment.baseApiUrl + 'api/LiveStock/GetTodayOfferProduct',
    getTrendsProduct: environment.baseApiUrl + 'api/LiveStock/GetTrendsProducts?Version=1&ProdCount=',
    getPromoBanners: environment.baseApiUrl + 'api/Banner/v1/Get_SpecialBanner?',
    getPromoProductBeyondHariana: environment.baseApiUrl + 'api/KitchenGarden/GetKGPCategorySubCategoryWiseData',
    getUserAddressAPI: environment.baseUrl + 'bz_FarmerApp/ProductDetail.svc/api/GetStateDistrictBlockVilage?apiKey=123&Id=',
    updateProifleDetails: environment.baseUrl + 'bz_FarmerApp/ProductDetail.svc/api/UpdateFarmerData',
    getExistingFarmerDetails: environment.baseApiUrl + 'api/Home/GetFarmerAddress?Version=1&FarmerID=',
    getOrderHistory:environment.baseApiUrl+'api/Home/Get_OrderHistory?Farmerid=',
    getNotificatins:environment.baseApiUrl+ 'api/home/BuyerBestDealDetails?BuyerID='
} 

