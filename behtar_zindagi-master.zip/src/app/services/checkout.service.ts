import { Injectable } from '@angular/core';
import { API_PATH } from '../utilis/app.config';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CheckoutService {

  constructor(private http: HttpClient ) { }

  checkout(bodyObj:{}){
    const httpOptions = {
      headers: new HttpHeaders({
        "district": bodyObj["district"],
        "state": bodyObj["state"]
      })
    }
    const body = {
      "apiKey": "123",
      "userid": bodyObj["userId"],
      "ModeOfPayment": "cod",
      "Product": [
          {
              "PackageId": bodyObj["packageID"],
              "Quantity": bodyObj["quantity"],
              "RecordId": bodyObj["recordID"],
          }
      ],
      "Farmer": {
          "FarmerId": bodyObj["farmerId"],
          "FarmerName": bodyObj["farmerName"],
          "FatherName": "",
          "Mobile": bodyObj["farmerMob"],
          "OtherVillageName": "",
          "Address": bodyObj["address"],
          "VillageId": '',
          "BlockId": '',
          "DistrictId": bodyObj["districtID"],
          "StateId": bodyObj["stateID"],
       }
    } 
    return this.http.post(API_PATH.orderCreate, body, httpOptions);    
  }

 
}
