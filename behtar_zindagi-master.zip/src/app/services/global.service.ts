import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import {API_PATH} from '../utilis/app.config'
@Injectable({
  providedIn: 'root'
})
export class GlobalService {


public defaultLocationObj:any  = new BehaviorSubject({});
public isLocationChange:any = new BehaviorSubject(false);
public loginUserObj:any = new BehaviorSubject({});
public isManualLocation:any = new BehaviorSubject(false);

constructor(private http:HttpClient) {  }
  showHideLoader = false;
  HideLoader = true;
  excelHideLoader = true;
  billLoader = false;


getAddress(selectedID, addressType):Observable<any>{
   return  this.http.get<any>(API_PATH.getUserAddressAPI+`${selectedID}&type=${addressType}`);
}

saveProfileDetails(Obj:any){
  const body = {
    "apiKey": "123",
    "FarmerId": Obj["farmerId"],
    "userid": Obj["farmerId"],
    "Email": Obj["email"],
    "RefSource": "",
    "Fname": Obj["firstName"],
    "Lname":  Obj["lastName"],
    "FatherName": "",
    "Mobile":  Obj["mobile"],   
    "StateId":  Obj["stateId"],    
    "DistrictId":  Obj["districtId"],  
    "BlockId":  Obj["blockId"],    
    "VillageId": Obj["villageId"],    
    "NearByVillage": Obj["nearbyVillage"],   
    "Address":  Obj["address"],   
    "Landmark": "",    
    "PinCode": "",    
  } 
  return this.http.post(API_PATH.updateProifleDetails, body);  
}


getExistingFarmerDetails(farmerId):Observable<any>{
  return this.http.get<any>(API_PATH.getExistingFarmerDetails+farmerId)
}

getOrderHistory(farmerId):Observable<any>{
  return this.http.get<any>(API_PATH.getOrderHistory+farmerId)
}

getNotificationsHistory(buyerId):Observable<any>{
  return this.http.get(API_PATH.getNotificatins+buyerId)
}

  getLoaderState() {
    return this.HideLoader;
  }

  setLoaderState(value) {
    this.HideLoader = value;
  }
}


