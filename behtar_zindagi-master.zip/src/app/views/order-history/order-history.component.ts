import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GlobalService } from 'src/app/services/global.service';

@Component({
  selector: 'app-order-history',
  templateUrl: './order-history.component.html',
  styleUrls: ['./order-history.component.css']
})
export class OrderHistoryComponent implements OnInit {
  orderHistory:any=[];
  isLoaded:boolean = false;
  constructor(private globalService:GlobalService, private router:Router) { }

  ngOnInit(): void {
    this.getOrder();

  }  
  
  getOrder(){
    let farmerID = localStorage.getItem('FarmerId');
    this.globalService.getOrderHistory(farmerID).subscribe(
      res =>{
        if(res["Status"]){
          this.orderHistory = res["OrderRecords"].OrderRecords
          console.log(this.orderHistory);
        }
      },
      err=> console.log(err),
      () => this.isLoaded = true
    )
  }

  goToProdcutDetail(item){
    let farmerID = localStorage.getItem('FarmerId');
    if(farmerID){
      this.router.navigate(['/bz/checkout', item.recordId]);
    }   
  }


}
