import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { CategoryService } from 'src/app/services/category.service';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from '../../shared/dialog/dialog.component';
import { CheckoutService } from 'src/app/services/checkout.service';
import { GlobalService } from 'src/app/services/global.service';
import { LoginComponent } from '../../login/login.component';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {  
  districtId:any;  // NOT IN USE
  productId:any;  
  quantity = [1,2,3,4,5,6,7,8,9,10];
 
  addressValue:any;  
  stateName:any;
  districtName:any;
  dealerID:any;
  isExistAddress:boolean;
  constructor(
    private categoryService: CategoryService,
    private router: Router,
    private route: ActivatedRoute,
    public dialog: MatDialog,
    private _location: Location,
    private checkoutService: CheckoutService,
    private toastr:ToastrService,
    private globalService:GlobalService){
    this.globalService.defaultLocationObj.subscribe(res=>{
      this.stateName = res["state"];
      this.districtName = res["district"];
    })
   this.route.queryParams.subscribe(res=> this.dealerID = res["dealerid"]);  
   }

  ngOnInit(): void {      
   this.getProduct(); 
   this.isCompleteProfile();   
  }


  isCompleteProfile(){   
    let  farmerID = localStorage.getItem('FarmerId');
    this.globalService.getExistingFarmerDetails(farmerID).subscribe(
      res => {            
        if(res["Status"]){              
        if((res["BZAppFarmerAddress"].Address !== null) && (res["BZAppFarmerAddress"].VillageName !== "APP_VILLAGE" || res["BZAppFarmerAddress"].VillageName !== null) ){
            this.isExistAddress = true
          }else{
            this.isExistAddress = false
          }
        }
      },
      err => console.log(err)
    )      
  }

  /**GET PRODUCT DETAILS**/
  farmerId:any;
  farmerName:any;
  farmerMob:any;
  farmerDistrictId:any;
  farmerStateId:any;
  address:any; 
  getProduct(){
    this.route.params.subscribe((res: any) => {
      this.productId = res.productId;
      const districtId = localStorage.getItem('districtId') || 0;
      const lat = Number(localStorage.getItem('lat') || 0);
      const lon = Number(localStorage.getItem('long') || 0);
      this.farmerId = localStorage.getItem('FarmerId') || 0;
      this.farmerName = localStorage.getItem('FarmerName');
      this.farmerMob = localStorage.getItem('farmerMob');
      this.farmerDistrictId = localStorage.getItem('haryanaDistrictId');
      this.farmerStateId = localStorage.getItem('stateId');
      this.address = localStorage.getItem('farmerAdd');
      if(this.address){
        this.addressValue = this.address;
      }
      if (this.farmerId) {
        this.getProductDetailWithFarmerId(this.productId, districtId, this.farmerId, lat, lon);
      } else{
        const dialogRef = this.dialog.open(LoginComponent);
        dialogRef.afterClosed().subscribe(result => {
          console.log(`Dialog result: ${result}`);
        });      
      }
    }) 
  }

  /**GET PRODUCT DETAILS WITH FARMER ID**/
  totalQuantity:any
  totalAmount:any
  singleItemPrice:number;
  productDetails: any = [];  
  getProductDetailWithFarmerId(ProductId, Districtid, FarmerId, lat, lon) {
    this.categoryService.getProductDetailsWithFarmerId(ProductId, Districtid, FarmerId, lat, lon).subscribe((res: any) => {
      if (res.Status) {
        if (res.BZApiReponse) {         
          this.productDetails = res["BZApiReponse"].ProductDetails
          console.log(this.productDetails);
          this.totalQuantity = this.productDetails[0].Quantity;
          this.totalAmount = this.productDetails[0].OnlinePrice;
          this.singleItemPrice = this.productDetails[0].OnlinePrice;        
        }
      }
    }, err => console.log(err))
  }

/**SET PRICE WITH RESPECT OF QUANTITY**/
  quantityValue:any = 1
  selectedValue(value){   
    this.quantityValue = Number(value);   
    this.totalAmount = this.singleItemPrice * this.quantityValue    
  }

/**CHECKOUT THE ITEM**/
  checkout() {      
    console.log(this.isExistAddress);
    if(this.isExistAddress){
      let userIds:any;
      if(this.stateName === 'HARYANA'){
        userIds = 0;
      }else{
        userIds = this.dealerID   
      }  
      let obj = {};
      obj["state"] = this.stateName;
      obj["district"] = this.districtName;
      obj["farmerId"] = this.farmerId;
      obj["packageID"] = this.productDetails[0].PackageID; 
      obj["quantity"] = this.quantityValue
      obj["recordID"] = this.productDetails[0].RecordID;
      obj["farmerName"] = this.farmerName;
      obj["farmerMob"] = this.farmerMob;
      obj["address"] = this.addressValue; 
      obj["districtID"] = this.farmerDistrictId;
      obj["stateID"] = this.farmerStateId;      
      obj["userId"] = userIds;      
      console.log(obj)
      this.checkoutService.checkout(obj).subscribe((res: any) => {
        console.log(res);
        if(res.Status == 1){
          this.toastr.success('Your order has been created successfully', 'Success!!');         
          this.router.navigate(['/']);
        }else{
          this.toastr.error('Order not created, kindly contact customer care', 'Error!!');  
        }       
      })
    }
    else{
      this.router.navigate(['/bz/profile'], {queryParams:{info:'Update Profile'}});
    }    
  }

  /**GO BACK**/
  goToBack(){
    this._location.back();
  }


}
