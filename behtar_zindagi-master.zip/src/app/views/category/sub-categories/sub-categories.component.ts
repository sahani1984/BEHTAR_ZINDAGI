import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/services/category.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { GlobalService } from 'src/app/services/global.service';

@Component({
  selector: 'app-sub-categories',
  templateUrl: './sub-categories.component.html',
  styleUrls: ['./sub-categories.component.css']
})
export class SubCategoriesComponent implements OnInit {
  subCategoryList: any = [];
  categoryId: any
  firstCategoryId: any
  productsList: any = [];
  slideConfig = {
    autoplay: false, slidesToShow: 7, slidesToScroll: 1, dots: false, autoplaySpeed: 4000,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 3
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 3
        }
      }
    ]
  };
  selectedIndex: number = 0;
  filterData: any = [];
  subCategoryWrapper: boolean = true;
  filterWrapper: boolean = true;
  productWrapper: boolean = true;
  state: any;
  district: any
  latLong: any
  productCategoryTitle: any = '';
  subCategoryTitle: any = ''
  constructor(
    private categoryService: CategoryService,
    private commonService: CommonService,
    private globalService: GlobalService,
    private router: Router,
    private route: ActivatedRoute,
  ) {
    this.globalService.defaultLocationObj.subscribe(res => this.state = res["state"])
    this.route.queryParams.subscribe(res => this.productCategoryTitle = res["category"])
  }

  ngOnInit(): void {
    this.commonService.getLatLongMessage().subscribe((res: any) => {
      if (res) {
        this.latLong = res;
      }
    })

    this.route.params.subscribe((res: any) => {
      if (res && res.categoryId) {
        this.categoryId = res.categoryId;
        const kgpStatus = localStorage.getItem('kgpStatus');
        console.log(kgpStatus)
        if (kgpStatus == '1') {
          this.subCategoryWrapper = true;
          this.getSubCategoriesList();
        } else {
          this.subCategoryWrapper = false;
          const haryanaDistrictId = localStorage.getItem('haryanaDistrictId');
          this.getHaryanaProducts(this.categoryId, haryanaDistrictId);
          this.getSubCategoriesFilter(this.categoryId);
        }
      }
    });
  }


  setIndex(index: number) {
    this.selectedIndex = index;
  }

  getSubCategoriesList() {
    this.categoryService.getSubCategory(this.categoryId).subscribe((res: any) => {
      this.subCategoryList = res.BZAppSubCatagory.BZFarmerAppSubCatagory;
      this.firstCategoryId = this.subCategoryList[0].CategoryID;
      this.subCategoryTitle = this.subCategoryList[0].CategoryName;
      console.log(this.subCategoryList);
      if (this.firstCategoryId) {
        this.getSubCategoriesProducts(this.firstCategoryId);
        this.getSubCategoriesFilter(this.firstCategoryId);
      }

    }, err => {
      console.log(err);
    })
  }

  goToSubcategory(item) {
    this.subCategoryTitle = item.CategoryName;
    this.getSubCategoriesProducts(item.CategoryID);
    this.getSubCategoriesFilter(item.CategoryID);
  }


  getSubCategoriesProducts(id) {
    this.productsList = [];
    this.categoryService.getSubCategoryProduct(id).subscribe(
      (res: any) => {
        if (res.ProductsApiReponse.Product.length > 0) {
          this.productWrapper = true;
          this.productsList = res.ProductsApiReponse.Product;
          console.log('pan india', res.ProductsApiReponse.Product);
          //console.log('haryan', this.productsList);
        } else {
          this.productWrapper = false;
        }
      }, err => console.log(err))
  }

  getHaryanaProducts(catId, districtId) {
    this.categoryService.getHaryanCategoryProducts(catId, districtId).subscribe((res: any) => {
      if (res.Status) {
        this.productsList = res.ProductsApiReponse.Product;
        console.log('haryana', this.productsList);
      }
    }, err => console.log(err))
  }

  goToProdcutDetail(data) {
    if (data) {
      if (this.latLong) {
        this.commonService.sendLatLongMessage(this.latLong);
        localStorage.setItem('latData', this.latLong.lat);
        localStorage.setItem('longData', this.latLong.long);
      }
      this.router.navigate(['/bz/product-detail', data.RecordID]);
    }
  }

  getSubCategoriesFilter(id) {
    this.filterData = [];
    this.categoryService.getSubCategoriesFilter(id).subscribe((res: any) => {
      if (res.KGPApiReponse) {
        this.filterWrapper = true;
        this.filterData = res.KGPApiReponse;
      } else {
        this.filterWrapper = false;
      }
    }, err => console.log(err))
  }

}
