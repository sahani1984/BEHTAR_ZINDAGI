import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { GlobalService } from 'src/app/services/global.service';
import { MatDialog } from '@angular/material/dialog';
declare var $: any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm:FormGroup;
  verifyOtpForm: FormGroup;

  loginWrapperBox: boolean = true;
  loginStatus: boolean = true;
  resendOtp: boolean = false;
  showHint:boolean = false;

  mobileNo:any;
  farmerName:any;

  constructor(
    private authService:AuthService,
    private globalService:GlobalService,
    private fb:FormBuilder,
    private dialog:MatDialog
  ) { }

  ngOnInit(): void {
    this.createLoginForm();
    this.createVerifyForm();    
  }

  onLoginSubmit(){
    this.authService.getOTP(this.loginForm.get('mob').value).subscribe((res: any) => {
      this.mobileNo = this.loginForm.get('mob').value;
      this.loginWrapperBox = false;
    }, err => console.log(err))   
  }

  onVerifyOtp(){
    this.authService.verfifyOTP(this.mobileNo, this.verifyOtpForm.get('otp').value).subscribe((res: any) => {
      if(res.success){
        this.loginStatus = false;
        const farmerName = this.loginForm.get('full_name').value;        
        this.farmerLogin(this.mobileNo, farmerName);      
        this.verifyOtpForm.reset();
      }else{
        alert('OTP is incorrect');
      }     
    }, err => console.log(err))   
   
  }

  
  resendOTP(){
    this.authService.getOTP(this.loginForm.get('mob').value).subscribe((res: any) => {
      this.mobileNo = this.loginForm.get('mob').value;
      this.resendOtp = !this.resendOtp;
      this.loginWrapperBox = false;
      localStorage.setItem('loginMessage', res.message);
    }, err => {
      console.log(err);
    })
  }


  private farmerLogin(phoneNo, farmerName){
    this.authService.farmerAppLogin(phoneNo, 0, 0, 0, farmerName).subscribe((res: any) => {
      console.log('res', res);
      if(res[0].Status){
        let loginObj = {};
        loginObj["username"] = res[0].FirstName
        loginObj["loginStatus"] = true;
        loginObj["FarmerID"] = res[0].FarmerID;
        this.globalService.loginUserObj.next(loginObj);        
        this.dialog.closeAll();     
        //this.farmerName = res[0].FirstName;
        localStorage.setItem('FarmerId', res[0].FarmerID);
        localStorage.setItem('FarmerName', res[0].FirstName);
        localStorage.setItem('farmerAdd', res[0].Address);
        localStorage.setItem('BlockName', res[0].BlockName);
        localStorage.setItem('DistrictName', res[0].DistrictName);
        localStorage.setItem('NearByVillage', res[0].NearByVillage);
        localStorage.setItem('VillageName', res[0].VillageName);
        localStorage.setItem('Address', res[0].Address);
        localStorage.setItem('farmerMob', phoneNo)
        localStorage.setItem('loginStatus', 'true');        
      }
    }, err => console.log(err))   
  }

  goBack(){
    this.loginWrapperBox = true;
  }

  keyPressEvent(event: any) {
    const pattern = /[0-9\+\-\ ]/;
    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }

  createLoginForm(){
    this.loginForm = this.fb.group({
      full_name: ['', [Validators.required, Validators.pattern('^[A-Za-z\u0900-\u097F]{4}[A-Za-z \u0900-\u097F]+')]],
      mob: ['', [Validators.required, Validators.pattern('^[6789][0-9]{9}$')]]
    })
  }

  createVerifyForm(){
    this.verifyOtpForm = this.fb.group({
      otp: ['', Validators.required]
    })
  }

}
