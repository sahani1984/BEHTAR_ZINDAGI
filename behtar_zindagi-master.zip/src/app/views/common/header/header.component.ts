import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HomeService } from 'src/app/services/home.service';
import { MapsAPILoader } from '@agm/core';
import { Router } from '@angular/router';
import { CategoryService } from 'src/app/services/category.service';
import { CommonService } from 'src/app/services/common.service';
import { LoginComponent } from '../../login/login.component';
import { MatDialog } from '@angular/material/dialog';
import { GlobalService } from 'src/app/services/global.service';
declare var $: any;

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  locationForm: FormGroup;
  loginWrapperBox: boolean = true;
  stateList: any = [];
  districtList: any = [];
  stateName: any
  districtName: any
  closeIcon: boolean = false;
  farmerCategoryList: any = [];
  loginStatus: boolean = false;
  latitude: any;
  longitude: any;
  zoom: number;
  address: string;
  private geoCoder: any;
  categoryWrapper: boolean = false;
  categoryWrapperMobile: boolean = false;
  bannersList: any = [];
  accountSubMenu: boolean = false;
  resendOtp: boolean = false;
  farmerName: any
  stateId: any
  districtId: any;
  distric:any;
  state:any;
  constructor(
    private fb: FormBuilder,
    private commonService: CommonService,
    private categoryService: CategoryService,
    private homeService: HomeService,
    private mapsAPILoader: MapsAPILoader,
    public router: Router,
    private globalService: GlobalService,
    private dialog: MatDialog) {
    /**TO DETECT LOGIN AND GET DETAILS**/
    this.globalService.loginUserObj.subscribe((res: any) => {     
      if (Object.keys(res).length) {
        this.farmerName = res.username;
        this.loginStatus = res.loginStatus;
      }
    });
    this.globalService.defaultLocationObj.subscribe(res=>{    
      if(Object.keys(res).length){
        this.state = res["state"];
        this.distric = res["district"];
      }
    })
    this.categoryService.categoryList.subscribe((res: any) => this.farmerCategoryList = res)
  }
  
  ngOnInit(): void {
    this.mapsAPILoader.load().then(() => {
      this.setCurrentLocation();
      this.geoCoder = new google.maps.Geocoder;
      this.getFarmersAppservices();
    });
    const state = localStorage.getItem('state');
    const district = localStorage.getItem('district');
    if (state && district) {
      this.stateName = state;
      this.districtName = district;
      this.commonService.sendManualLocationMessage({ state: this.stateName, district: this.districtName });
      this.commonService.sendLocationMessage({ state: this.stateName, district: this.districtName });
    } else {
      this.getLocation();
    }

    this.createAddUserForm();
    this.getStateListData();

    
    this.commonService.getLocationMessage().subscribe((res: any) => {
      if (res) {
        this.districtName = res.district;
        this.stateName = res.state;
        this.distric = res.district;
        this.state  =  res.state;
      }
    });   

  }


  createAddUserForm() {
    this.locationForm = this.fb.group({
      state: ['', Validators.required],
      district: ['', Validators.required]
    })
  }

  getStateListData() {
    this.homeService.getStateList().subscribe((res: any) => {
      this.stateList = res.List;
    }, err => console.log(err))
  }

  category() {
    this.categoryWrapper = !this.categoryWrapper;
  }


  addState(stateId: any) {
    this.locationForm.patchValue({
      district:""
    })    
    let result = stateId.substr(0, stateId.indexOf(' '));
    this.stateName = stateId.substr(stateId.indexOf(' ') + 1);
    this.stateId = stateId.substr(0, stateId.indexOf(' '));
    this.homeService.getDistrictList(result).subscribe((res: any) => {
      this.districtList = res.List;
    }, err => console.log(err))   
  }

  addDistrict(districtId) {
    this.districtId = districtId.toString().split(' ')[0];
    this.districtName = districtId.toString().split(' ')[1];   
   }


  waitForOneSecond(data) {
    return new Promise(resolve => {
      resolve(data)
    });
  }

  getLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(this.showPosition, this.showError);
    } else {
      console.log("Geolocation is not supported by this browser.");
    }
  }

  showPosition(position) {
    localStorage.setItem('lat', position.coords.latitude)
    localStorage.setItem('long', position.coords.longitude)
    console.log(position.coords.latitude, position.coords.longitude);
  }

  showError(error) {
    switch (error.code) {
      case error.PERMISSION_DENIED:
        $('#myModal').modal({
          backdrop: 'static',
          keyboard: false
        });
        localStorage.setItem('isBlockLocation', 'true');
        console.log("User denied the request for Geolocation.");
        break;
      case error.POSITION_UNAVAILABLE:
        console.log("Location information is unavailable.")
        break;
      case error.TIMEOUT:
        console.log("The request to get user location timed out.")
        break;
      case error.UNKNOWN_ERROR:
        console.log("An unknown error occurred.")
        break;
    }
  }

  private setCurrentLocation() {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition((position: any) => {
        this.latitude = position.coords.latitude;
        this.longitude = position.coords.longitude;
        this.zoom = 8;
        this.commonService.sendLatLongMessage({ lat: this.latitude, long: this.longitude })
        this.getAddress(this.latitude, this.longitude);
        this.getFarmersAppservices();
      });
    }
  }

  getAddress(latitude, longitude) {
    this.geoCoder.geocode({ 'location': { lat: latitude, lng: longitude } }, (results, status) => {
      if (status === 'OK') {
        let city, region, country;
        if (results[1]) {
          var indice = 0;
          for (var j = 0; j < results.length; j++) {
            if (results[j].types[0] == 'locality') {
              indice = j;
              break;
            }
          }
          for (var i = 0; i < results[j].address_components.length; i++) {
            if (results[j].address_components[i].types[0] == "locality") {
              //this is the object you are looking for City
              city = results[j].address_components[i];
            }
            if (results[j].address_components[i].types[0] == "administrative_area_level_1") {
              //this is the object you are looking for State
              region = results[j].address_components[i];
            }
            if (results[j].address_components[i].types[0] == "country") {
              //this is the object you are looking for
              country = results[j].address_components[i];
            }
          }
          //city data
          console.log(city.long_name + " || " + region.long_name + " || " + country.short_name);
          if (this.stateName && this.districtName) {
            this.commonService.sendLocationMessage({ state: this.stateName, district: this.districtName });
          } else {
            this.districtName = city.long_name;
            this.stateName = region.long_name;
            this.commonService.sendLocationMessage({ state: this.stateName, district: this.districtName });
            this.globalService.defaultLocationObj.next({ state: this.stateName, district: this.districtName });
          }
          this.getFarmersAppservices();
        } else {
          console.log("No results found");
        }
      } else {
        console.log('Geocoder failed due to: ' + status);
      }

    });
  }

  goBack() {
    this.loginWrapperBox = true;
  }

  locationModal() {
    $('#myModal').modal({
      backdrop: 'static',
      keyboard: false
    });
    this.closeIcon = true;
    this.getFarmersAppservices();
  }

  loginWrapper() {
    const dialogRef = this.dialog.open(LoginComponent);
    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }


  getFarmersAppservices() {
    if (this.districtName && this.stateName) {
      this.categoryService.getFarmerAppServices(this.districtName, this.stateName).subscribe((res: any) => {
        if (res.Status) {
          localStorage.setItem('haryanaDistrictId', res.Location[0].DistrictId);
          this.commonService.sendDistrictMessage({ stateId: res.Location[0].StateId, districtId: res.Location[0].DistrictId });
        }
      },
        err => console.log(err))
    }
  }

  keyPressEvent(event: any) {
    const pattern = /[0-9\+\-\ ]/;
    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }

  onSubmit(dataObj) {
    //console.log(dataObj);
    this.commonService.sendManualLocationMessage({ state: this.stateName, district: this.districtName });
    this.commonService.sendDistrictMessage({ stateId: this.stateId, districtId: this.districtId });
    this.commonService.sendLocationMessage({ state: this.stateName, district: this.districtName });
    localStorage.setItem('district', this.districtName);
    localStorage.setItem('districtId', this.districtId);
    localStorage.setItem('state', this.stateName);
    localStorage.setItem('isManualLocation', 'true')
    this.globalService.defaultLocationObj.next({ state: this.stateName, district: this.districtName, districtId: this.districtId })
    this.globalService.isLocationChange.next(true);
    this.getFarmersAppservices();
     //this.categoryService.sendMessage({'state': state, 'district': district})
    $('#myModal').modal('hide');
  }


  signOut() {
    localStorage.removeItem('district');
    localStorage.removeItem('FarmerId');
    localStorage.removeItem('haryanaDistrictId');
    localStorage.removeItem('farmerMob');
    localStorage.removeItem('stateId');
    localStorage.removeItem('state');
    localStorage.removeItem('FarmerName');
    localStorage.removeItem('lat');
    localStorage.removeItem('long');
    localStorage.removeItem('isManualLocation');
    localStorage.removeItem('loginStatus');
    localStorage.removeItem('BlockName');
    localStorage.removeItem('DistrictName');
    localStorage.removeItem('NearByVillage');
    localStorage.removeItem('VillageName');
    let loginObj = {};
    loginObj["username"] = null
    loginObj["loginStatus"] = false;
    loginObj["FarmerID"] = null;
    this.globalService.loginUserObj.next(loginObj);
    this.commonService.sendLoginMessage({ isLogin: false, farmerId: null, farmerName: null, farmerMob: null })
    this.loginStatus = false;
    this.loginWrapperBox = true;

  }


  goToSubcategory(item) {
    localStorage.setItem('kgpStatus', item.isKGP_Category);
    this.router.navigate(['/bz/category', item.CategoryId], { queryParams: { category: item.Categoryname } });
    this.categoryWrapper = false;
    this.categoryWrapperMobile = false;
  }

  navigateToProfile() {
    this.router.navigate(['/bz/profile']);
  }

  categoryMobile() {
    this.categoryWrapperMobile = !this.categoryWrapperMobile;
  }

  gotoHomePage() {
    this.router.navigate(['/']);
    this.categoryWrapperMobile = false;
  }


}
