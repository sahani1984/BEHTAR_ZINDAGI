import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SlickCarouselModule } from 'ngx-slick-carousel';

import { DefaultRoutingModule } from './default-routing.module';
import { DefaultComponent } from './default.component';
import {BannersComponent} from './banners/banners.component'
import {CategoryListComponent} from  './category-list/category-list.component';
import { PromoBannerComponent } from './promo-banner/promo-banner.component';
import {BrandsComponent} from './brands/brands.component';

@NgModule({
  declarations: [
    DefaultComponent,
    BannersComponent,
    CategoryListComponent,
    PromoBannerComponent,
    BrandsComponent
  ],
  imports: [
    CommonModule,
    DefaultRoutingModule,
    SlickCarouselModule
  ],
  exports: [
    DefaultComponent
  ]

})
export class DefaultModule { }
