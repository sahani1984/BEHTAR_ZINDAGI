import { Component, OnInit } from '@angular/core';
import { HomeService } from 'src/app/services/home.service';
import { CommonService } from 'src/app/services/common.service';
import { GlobalService } from 'src/app/services/global.service';
import { Router } from '@angular/router';
import { CategoryService } from 'src/app/services/category.service';
import { take, throttleTime } from 'rxjs/operators';

@Component({
  selector: 'app-default',
  templateUrl: './default.component.html',
  styleUrls: ['./default.component.css']
})
export class DefaultComponent implements OnInit {
  slideConfig = {
    autoplay: true, 
    slidesToShow: 5, 
    slidesToScroll: 1,  
    dots: false, 
    autoplaySpeed: 5000,
    nextArrow: `<div class="slide_next"><i class="fa fa-arrow-left slick-arrow slider-next"></i></div>`,
    prevArrow: `<div class="slide_prev"><i class="fa fa-arrow-right slick-arrow slider-prev"></i></div>`,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1
        }
      }
    ]
  };
  slideConfig2 = {
    autoplay: true, 
    slidesToShow: 5, 
    slidesToScroll: 1,  
    dots: false, 
    autoplaySpeed: 2000,
    nextArrow: `<div class="slide_next"><i class="fa fa-arrow-left slick-arrow slider-next"></i></div>`,
    prevArrow: `<div class="slide_prev"><i class="fa fa-arrow-right slick-arrow slider-prev"></i></div>`,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1
        }
      }
    ]
  };

  slideConfig3 = {
    autoplay: true, 
    slidesToShow: 5, 
    slidesToScroll: 1,  
    dots: false, 
    autoplaySpeed: 2000,
    nextArrow: `<div class="slide_next"><i class="fa fa-arrow-left slick-arrow slider-next"></i></div>`,
    prevArrow: `<div class="slide_prev"><i class="fa fa-arrow-right slick-arrow slider-prev"></i></div>`,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1
        }
      }
    ]
  };

    
  state:any;
  district:any;
  todaysOfferWrapper:boolean = false; 
  latLong:any; 
  constructor(private homeService:HomeService, 
    private commonService: CommonService,
    private globalService:GlobalService,  
    private router: Router, 
    private categoryService: CategoryService) {
    this.globalService.defaultLocationObj.subscribe(res=>{
      this.state = res["state"];
      this.district = res["district"];     
    }); 
   
   }

  ngOnInit(): void {
    /**SET LAT-LONG**/
    this.commonService.getLatLongMessage()
    .pipe(take(1))
    .subscribe((res: any) => {   
      console.log(res);  
      if(res){
        this.latLong = res;
      }
    })   
   
    this.categoryService.getMessage()
    .pipe(throttleTime(5000))
    .subscribe((res: any) => {        
      if(res.text == true){
        this.todaysOfferWrapper = true;
        this.getTodaysOffer();
        this.getTrendsProduct();
      }else{
        this.todaysOfferWrapper = false;
        this.getTopSellingProducts();
        this.getBehtarBachatProducts();
      }
    })          
  }

  
  /**GET SELLING PRODUCTS**/
  sellingProducts:any = [];
  getTopSellingProducts(){
   this.homeService.getTopSellingProducts(this.district, this.state, 0).subscribe((res: any) => {
   this.sellingProducts = res.ProductsApiReponse.Product;
   }, err => {
     console.log(err);
   })
  }


  /**GET BEHTAR BACHAT PRODUCTS**/
  behtarBachatProducts: any = [];
  getBehtarBachatProducts(){
    this.homeService.getBehtarBachatProducts(this.district, this.state, 0)
    .subscribe((res: any) => {
      this.behtarBachatProducts = res.ProductsApiReponse.Product;
      console.log(this.behtarBachatProducts)
    }, err => {
      console.log(err);
    })
  }
  

  /**GET TODAYS OFFTER**/
  todaysOffer: any = [];
  getTodaysOffer(){
    this.categoryService.getTodaysOffer(this.district, this.state, 0).subscribe((res: any) => {
      if(res.Status){
        this.todaysOffer = res.ProductsApiReponse.Product;
      }     
    }, err => {
      console.log(err);
    })
  }

  /**GET TREND PRODUCTS**/
  trendProducts: any = [];
  getTrendsProduct(){
    this.categoryService.getTrendsProduct(this.district, this.state, 0).subscribe((res: any) => {
      if(res.Status){
        this.trendProducts = res.ProductsApiReponse.Product;
        console.log(this.trendProducts)
      }
    }, err => {
      console.log(err);
    })
  }



  /**GO TO DETAILS PAGE**/
  goToDetailPage(id, category){
    if(this.latLong){     
      localStorage.setItem('latData', this.latLong.lat);
      localStorage.setItem('longData', this.latLong.long);
    }
    this.router.navigate(['/bz/product-detail', id], {queryParams:{category:category}})
  }

/**TO TO SEE MORE**/
goToSeeMore(value){
  localStorage.setItem('see-more', value);
  this.commonService.sendSeeMoreMessage(value);
  this.router.navigate(['/bz/see-more']);
}



}
