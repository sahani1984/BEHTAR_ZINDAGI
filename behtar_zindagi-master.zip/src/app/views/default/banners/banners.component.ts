import { Component, OnInit, Input } from '@angular/core';
import { HomeService } from 'src/app/services/home.service';
import { CommonService } from 'src/app/services/common.service';
import { CategoryService } from 'src/app/services/category.service';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { GlobalService } from 'src/app/services/global.service';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-banners',
  templateUrl: './banners.component.html',
  styleUrls: ['./banners.component.css']
})
export class BannersComponent implements OnInit {
  @Input() banners = []; 
  slideConfig = {
    autoplay: true, 
    slidesToShow: 2, 
    slidesToScroll: 1,  
    dots: false, 
    autoplaySpeed: 4000,
    "nextArrow": '<i class="fa fa-angle-right nextBtn" aria-hidden="true"></i>',
    "prevArrow": '<i class="fa fa-angle-left prevBtn" aria-hidden="true"></i>',
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1
        }
      }
    ]
  };


  state:any;
  district:any;
  districtId:any;
  constructor(
    private homeService: HomeService, 
    private commonService: CommonService, 
    private categoryService: CategoryService,
    private globalService:GlobalService,  
    public dialog: MatDialog, 
    private router: Router) { 
     
     } 
  ngOnInit(): void {    
    this.globalService.defaultLocationObj.subscribe((res:any)=>{     
      this.state = res["state"];
      this.district = res["district"];
      this.getBannersData(this.district, this.state);
    });
    this.globalService.isLocationChange.subscribe((res:any)=>{
      if(res){
        this.getBannersData(this.district, this.state);
      }
    });
      
  } 

  /**GET BANNER LIST**/
  bannersList: any = [];
  getBannersData(district, state){     
    if(district && state){  
    this.homeService.getBannersLists(district, state)
    .pipe(take(1))
    .subscribe((res: any) => {
      if(res.Status){
        this.bannersList = res["BZAppBanner"].BZProductBanner;   
        console.log(this.bannersList)    
      }     
    }, err => console.log(err))
   }
  }

  goToCategory(item){  
    if(item){
      this.router.navigate(['/bz/banner-products', item.CategoryId], {queryParams:{category:item.CategoryName}});
    }else{
      alert('Data not available'); 
    }
  }

/**FOR TRACKING EXISTING ITEM AND IGNORE DOM RENDERING**/
trackByImage(index: number, item: any): string {
  return item.ImagePath && item.CategoryId;
}

}
