import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { GlobalService } from './services/global.service';
import { CommonService } from './services/common.service';

declare let $: any;

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css'],
    providers: [
        Location, {
            provide: LocationStrategy,
            useClass: PathLocationStrategy
        }
    ]
})
export class AppComponent implements OnInit {
  location: any;
  routerSubscription: any;

  constructor(
    private router: Router, 
    private globalService:GlobalService,
    private commonService:CommonService
    ) {}

  ngOnInit(){   
     this.navigateToTop();
     this.setlocation();
     this.globalService.isLocationChange.subscribe(res=>{    
       if(res) window.location.reload(); 
     });
     this.checkIfLogin();
  }

/**GET LOCATION IF AVAILABLE IN STORAGE**/
setlocation(){    
    const st = localStorage.getItem('state');
    const dist = localStorage.getItem('district');
    const distId = localStorage.getItem('districtId');
    const isManualLocation = localStorage.getItem('isManualLocation');    
    if((st != null) || (dist != null)){
        this.globalService.defaultLocationObj.next({state:st, district:dist, districtId:distId});
        this.commonService.sendManualLocationMessage({state:st, district:dist});
        this.commonService.sendLocationMessage({state: st, district:dist});
     }
     if(isManualLocation && isManualLocation === 'true'){
       this.globalService.isManualLocation.next(true);
     }     
   }

   /**NAVIGATE TO EVERY NEW PAGE TO TOP VIEW**/
  navigateToTop(){
    this.router.events.subscribe((evt) => {
      if (evt instanceof NavigationEnd) {
         document.body.scrollTop = 0; 
      }
   });
  } 
 
  /**CHECK IF USER LOGGED IN**/
 checkIfLogin(){
   let logiStatus = localStorage.getItem('loginStatus')=="true"?true:false
   let obj = {};
   obj["FarmerID"] = localStorage.getItem('FarmerId');
   obj["username"] = localStorage.getItem('FarmerName');
   obj["loginStatus"] = logiStatus;
   if(logiStatus){
    this.globalService.loginUserObj.next(obj); 
   }  
 }

}
